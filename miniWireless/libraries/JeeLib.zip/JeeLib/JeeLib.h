#ifndef JeeLib_h
#define JeeLib_h

#include <Ports.h>
#include <RF12.h>

#endif
