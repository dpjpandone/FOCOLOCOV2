Work in progress - see <http://forum.jeelabs.net/node/457>

You can download this project in either
[zip](https://github.com/jcw/jeelib/zipball/master) or
[tar](https://github.com/jcw/jeelib/tarball/master) formats.

Unpack the archive and rename the result to `JeeLib`.  
Put it in the `libraries` folder in your Arduino sketches area.  
Restart the Arduino IDE to make sure it sees the new files.
